package de.redsix.pdfcompare;

public class RenderingException extends RuntimeException {

}
