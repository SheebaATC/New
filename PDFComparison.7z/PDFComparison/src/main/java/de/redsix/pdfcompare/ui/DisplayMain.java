package de.redsix.pdfcompare.ui;

import java.io.IOException;

public class DisplayMain {

    public static void main(String[] args) throws IOException {
        new Display().init();
    }
}
