package TC;
import java.io.IOException;

import de.redsix.pdfcompare.PdfComparator;

public class Test1 {
	
	public static void main(String args[]) throws IOException {

		String file1 = "E:\\PDFComparison\\Doc1.pdf";
		String file2 = "E:\\PDFComparison\\Doc2.pdf";
		String result = "E:\\PDFComparison\\Results\\Result.pdf";
		String ignoreFile = "C:\\Users\\User\\eclipse-workspace\\PDFComparison\\ignore.conf"; // mention which portion to ignore in ignore file
	//new PdfComparator(file1,file2).compare().writeTo(result);
	boolean writeTo = new PdfComparator(file1,file2).withIgnore(ignoreFile).compare().writeTo(result);
	
	
	boolean isEquals = new PdfComparator(file1,file2).withIgnore(ignoreFile).compare().writeTo(result);
	System.out.println("Are pdf files similar: " +isEquals);
	
	
	System.out.println("Completed");
	}
}
