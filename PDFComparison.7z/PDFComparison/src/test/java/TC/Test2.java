package TC;
import de.redsix.pdfcompare.PdfComparator;
import de.redsix.pdfcompare.env.SimpleEnvironment;

import java.awt.Color;
import java.io.IOException;

import org.testng.annotations.Test;

@SuppressWarnings("rawtypes")

public class Test2 {
	@Test
	public void sample() throws IOException
	{



		String file1 = "E:\\PDFComparison\\Doc1.pdf";
		String file2 = "E:\\PDFComparison\\Doc2.pdf";
		String result = "E:\\PDFComparison\\Results\\Result.pdf";
		String ignoreFile = "C:\\Users\\User\\eclipse-workspace\\PDFComparison\\ignore.conf"; // mention which portion to ignore in ignore file
		//boolean isEquals = new PdfComparator(file1,file2).withIgnore(ignoreFile).compare().writeTo(result);
		 new PdfComparator(file1,file2)
		.withEnvironment(new SimpleEnvironment() 
				.setExpectedColor(Color.blue))
		.compare().writeTo(result);
		//System.out.println("Are pdf files similar: " +isEquals);
		System.out.println("Completed");
	}

}
